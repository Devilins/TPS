from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import ReportUploadForm
from .models import FieldResult, ReportUpload
from .tasks import process_report


@login_required
def upload_view(request):
    if request.method == "POST":
        form = ReportUploadForm(request.POST, request.FILES)
        if form.is_valid():
            upload = form.save(commit=False)
            upload.uploaded_by = request.user
            upload.save()
            process_report.delay(upload.id)
            messages.success(request, "Фото принято, обрабатывается — обновите страницу через минуту.")
            return redirect("report_ocr:detail", pk=upload.pk)
    else:
        form = ReportUploadForm()
    return render(request, "report_ocr/upload.html", {"form": form})


@login_required
def list_view(request):
    uploads = ReportUpload.objects.select_related("location").all()[:200]
    return render(request, "report_ocr/list.html", {"uploads": uploads})


@login_required
def detail_view(request, pk):
    upload = get_object_or_404(ReportUpload.objects.select_related("location"), pk=pk)
    fields = list(upload.fields.all())
    fields.sort(key=lambda f: (not f.needs_review, f.section, f.field_name))
    return render(request, "report_ocr/detail.html", {"upload": upload, "fields": fields})


@login_required
def confirm_field_view(request, pk):
    if request.method != "POST":
        return HttpResponseForbidden()
    field = get_object_or_404(FieldResult, pk=pk)
    value = request.POST.get("value", "").strip()
    field.confirmed_value = value if value else field.extracted_value
    field.reviewed = True
    field.reviewed_by = request.user
    field.reviewed_at = timezone.now()
    field.save()
    return redirect("report_ocr:detail", pk=field.upload_id)
