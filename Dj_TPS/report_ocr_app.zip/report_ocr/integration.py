"""
Единственное место, которое нужно донастроить под вашу существующую CRM.
Ничего в pipeline/ и tasks.py трогать не придётся — они работают через этот интерфейс.
"""
from datetime import date


def get_system_report_data(location, report_date: date) -> dict[str, str]:
    """Возвращает эталонные значения из CRM за эту точку и дату — то, с чем
    будем сравнивать распознанное с фото.

    Ключи ДОЛЖНЫ совпадать с тем, как FieldResult.field_name/sub_field
    формируются в pipeline/runner.py, например:
        "Аккум. для фото|начало_дня" -> "2"
        "Аккум. для фото|конец_дня"  -> "2"
        "Общая касса|" -> "6500"

    TODO: замените на реальные запросы к вашим моделям продаж/расходников/техники,
    например:

        from equipment.models import EquipmentLog
        from sales.models import DailyCashReport
        ...
        logs = EquipmentLog.objects.filter(location=location, date=report_date)
        return {f"{log.item_name}|начало_дня": str(log.start_count) for log in logs} | {...}
    """
    raise NotImplementedError(
        "Подключите get_system_report_data к вашим моделям CRM (продажи/расходники/техника)"
    )


def field_key(field_name: str, sub_field: str) -> str:
    return f"{field_name}|{sub_field}"
