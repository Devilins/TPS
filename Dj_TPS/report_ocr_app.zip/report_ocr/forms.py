from django import forms

from .models import ReportUpload


class ReportUploadForm(forms.ModelForm):
    class Meta:
        model = ReportUpload
        fields = ["location", "report_date", "photo"]
        widgets = {
            "report_date": forms.DateInput(attrs={"type": "date"}),
        }
        labels = {
            "location": "Точка",
            "report_date": "Дата отчёта",
            "photo": "Фото бланка",
        }

    def clean_photo(self):
        photo = self.cleaned_data["photo"]
        if photo.size > 15 * 1024 * 1024:
            raise forms.ValidationError("Файл больше 15МБ — скорее всего, это не то фото.")
        return photo
